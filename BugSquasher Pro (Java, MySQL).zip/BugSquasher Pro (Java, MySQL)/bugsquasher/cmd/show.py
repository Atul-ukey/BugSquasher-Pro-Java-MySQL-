from bugsquasher.commands import BaseBug


class Cmd(BaseBug):

    name = 'show'
