from bugsquasher import commands


class Cmd(commands.BaseBug):
    name = 'take'
